﻿neomycin05 Mech Keyboard

Mech keyboard

I am going to build a mechanical keyboard. It will be a good addition to my setup as I do not have a separate keyboard yet. I am excited to build it because I have never built a keyboard yet and I always watch keyboard build videos on YouTube all the time so I have always wanted to build one.

Tools needed: Keyboard case. PCB compatible with that case. Switch mounting plate. Mechanical switches. Stabilizers. Keycaps. USB cable. Screwdriver. Optional: Soldering tools. Step 1: Decide What Keyboard You Want. … Step 2: Pick Out the Parts. … Step 3: Get the Equipment Required. … Step 4: Test PCB to Make Sure it Works. … Step 5: Lube Your Switches (Optional) … Step 6: Mod Your Stabilizers (Optional) … Step 7: Install Stabilizers Into PCB. … Step 8: Install Switches Into Plate & PCB. Step 9: Solder Switches. Step 10: Add Foam and Rubber Feet to The Case. Step 11: Install Assembled PCB Into Case. Step 12: Install the Keycaps. Step 13: The Typing Test.

GMK Red Samurai(keycaps):[ https://bit.ly/3u8WLsz](https://bit.ly/3u8WLsz) $95 Gateron Yellow (switches): <https://amzn.to/39sCNkM> $30 Plate: <https://amzn.to/3ma7PDa> $45

DZ60 (pcb): <https://bit.ly/3u8WLsz> $40
